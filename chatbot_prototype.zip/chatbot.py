# chatbot.py
# Simple prototype chatbot for financial queries

def simple_chatbot(user_query):
    # Predefined responses based on analyzed financial data
    if user_query.lower() == "what is the total revenue?":
        return "Microsoft (2024) total revenue: $245.1B. Tesla (2024): $96.8B. Apple (2024): $385.7B."
    
    elif user_query.lower() == "how has net income changed over the last year?":
        return "Microsoft's net income increased by 19% in 2024, Tesla's rose by 14%, and Apple's decreased by 3%."
    
    elif user_query.lower() == "what are the total assets?":
        return "Microsoft: $475.9B, Tesla: $113.7B, Apple: $387.0B (all 2024 figures)."
    
    elif user_query.lower() == "what are the total liabilities?":
        return "Microsoft: $212.2B, Tesla: $42.4B, Apple: $300.0B (2024 figures)."
    
    elif user_query.lower() == "what is the operating cash flow?":
        return "Microsoft: $110.5B, Tesla: $16.0B, Apple: $117.5B (2024 figures)."
    
    else:
        return "Sorry, I can only provide information on predefined queries."

if __name__ == "__main__":
    print("Welcome to the Financial Chatbot Prototype!")
    print("You can ask me things like:")
    print("- What is the total revenue?")
    print("- How has net income changed over the last year?")
    print("- What are the total assets?")
    print("- What are the total liabilities?")
    print("- What is the operating cash flow?")
    print("Type 'quit' to exit.\n")

    while True:
        user_query = input("You: ")
        if user_query.lower() == "quit":
            print("Chatbot: Goodbye!")
            break
        response = simple_chatbot(user_query)
        print("Chatbot:", response)
